package ocjp.excepciones.conceptos;

public class UncheckedException extends RuntimeException 
{

}
