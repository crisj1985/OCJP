package ocjp.excepciones.conceptos;

import java.util.zip.CheckedInputStream;

public class Hijo extends Padre
{
	public void metodo1() 
	{
		
	}
	public void metodo2() throws RuntimeException
	{
		
	}

}
