package ocjp.excepciones.conceptos;

public class TestEj5 {

	public static void main(String[] args) throws Exception 
	{
		Ejercicio5 ej5 = new Ejercicio5();
		/*ej5.metodo1();
		ej5.metodo2();
		ej5.metodo3(4);
		ej5.metodo4(23);
		ej5.metodo5();*/
		ej5.metodo4();
		ej5.metodo7();
		/*Padre p1 = new Padre();
		Hijo h1 = new Hijo();
		p1.metodo1();
		p1.metodo2();
		h1.metodo1();
		h1.metodo2();*/
		

	}

}
