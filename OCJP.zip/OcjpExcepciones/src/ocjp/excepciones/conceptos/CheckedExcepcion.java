package ocjp.excepciones.conceptos;

public class CheckedExcepcion extends Exception 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

	}

}
