package ocjp.excepciones.conceptos;

import java.io.IOException;

public class TestEj3 {

	public static void main(String[] args) throws IOException 
	{
		Ejercicio2 ej3 = new Ejercicio2();
		ej3.metodo2();
		ej3.metodo1();

	}

}
