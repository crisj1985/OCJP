package ocjp.excepciones.conceptos;

public class Padre 
{
	public void metodo1() throws CheckedExcepcion
	{
		
	}
	public void metodo2() throws UncheckedException
	{
		
	}
}
