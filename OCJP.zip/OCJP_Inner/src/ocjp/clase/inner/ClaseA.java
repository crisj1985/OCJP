package ocjp.clase.inner;

public class ClaseA 
{
	public void metodo1()
	{
		System.out.println("m1 en ClaseA");
	}
}
