package ocjp.arreglos;

public class Test {

	public static void main(String[] args) 
	{
		int [] arreglo1;
		int arreglo2 [];
		arreglo1= new int [4];
		//arreglo2= new int [];
//		int arreglo3[4];
		String arreglo4 []=new String [2];
		int arreglo5 []={4,8,9};
//		int arreglo6 []=new int [2]{4,8};
		int arreglo7 []=new int []{4,8};
		int arreglo8[];
//		arreglo8[]={4,6};
		
				

	}

}
