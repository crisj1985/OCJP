package ocjp.arreglos;

public class Arreglo_Multidimensionales 
{
	public static void main (String [] args)
	{
	int [][] arreglo1;
	arreglo1 = new int [4][];
//	int arreglo2 [][];
	int [] arreglo3 [];
	arreglo3= new int [3][];
//	int [][]arreglo4= new int [][];
//	int [6][]arreglo4= new int [][];
	String [][]arreglo5 = new String[4][];
	
	}

}
