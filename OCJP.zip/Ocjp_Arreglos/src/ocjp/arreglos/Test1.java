package ocjp.arreglos;

public class Test1 {

	public static void main(String[] args) {
		int arreglo1 [][]= new int [3][];
		arreglo1 [1]=new int [2];
		arreglo1[1][0]=5;
		arreglo1[1][1]=4;
		arreglo1 [2]=new int [1];
		arreglo1[2][0]=3;
		System.out.println(arreglo1[1][0]+" "+arreglo1[1][1]+" "+arreglo1 [2][0] );

	}

}
