package ocjp.archivos;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class BufferedReader 
{

	
	public static void main(String[] args) throws FileNotFoundException 
	{
		FileReader fr=new FileReader("archivo1.txt");
//		BufferedReader br=new BufferedReader(fr);

	}

}
