package ocjp.threads.conceptos;

public class OtroHilo implements Runnable{

	public void run() 
	{
		
	}

}
