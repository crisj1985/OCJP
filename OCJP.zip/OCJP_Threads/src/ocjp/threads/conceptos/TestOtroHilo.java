package ocjp.threads.conceptos;

public class TestOtroHilo {

	public static void main(String[] args) 
	{
		

	}

}
