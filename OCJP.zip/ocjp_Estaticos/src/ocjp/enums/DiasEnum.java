package ocjp.enums;

public enum DiasEnum 
{
	LUNES,MARTES, MIERCOLES,SABADO;
}
