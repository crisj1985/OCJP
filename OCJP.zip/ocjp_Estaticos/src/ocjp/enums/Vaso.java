package ocjp.enums;

import TamanioVaso.TamanioVaso;

public class Vaso {

//	Un atributo tamanio del tipo TamanioVaso. 
//	Un constructor que reciba un par�metro TamanioVaso y lo asigne al atributo tamanio.
//	Un atributo cantidadLiquido de tipo entero que indica la cantidad de liquido que tiene el vaso en cada momento. 

	
	TamanioVaso tamanio;
	int cantidadLiquido;
	public Vaso(TamanioVaso tamanio)
	{
		this.tamanio=tamanio;

	}

	public static void main(String[] args) 
	{
	
		

	}

}
