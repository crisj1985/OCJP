package ocjp.enums;

public interface Dias 
{
	int Lunes=1;
	final int Martes=2;
	
}
