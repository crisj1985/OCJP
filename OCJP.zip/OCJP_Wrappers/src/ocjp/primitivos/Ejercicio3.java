package ocjp.primitivos;

public class Ejercicio3 {

	
	public static void main(String[] args) 
	{
		Ejercicio3 o = new Ejercicio3();
		int s1=10;
		o.metodo1(s1);

	}
	
	void metodo1 (NUmber l)
	{
		System.out.println("Short Prmitivo");	
	} 
	void metodo1(Integer i)
	{
		System.out.println("Long");
	}
}
