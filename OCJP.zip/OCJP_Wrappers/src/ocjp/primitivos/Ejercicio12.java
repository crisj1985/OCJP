package ocjp.primitivos;

public class Ejercicio12 {

	public static void main(String[] args) 
	{
		Ejercicio12 o = new Ejercicio12();
		int s1=10;
		o.metodo1(s1);

	}
	
	void metodo1 (short l)
	{
		System.out.println("Short Prmitivo");	
	} 
	void metodo1(Integer i)
	{
		System.out.println("Integer");
	}
}
