package ocjp.primitivos;

public class Ejercicio5 {

	public static void main(String[] args) 
	{
		Ejercicio5 o = new Ejercicio5();
		Integer s1=10;
		o.metodo1(s1);

	}
	
	void metodo1 (int l)
	{
		System.out.println("Short Prmitivo");	
	} 
	void metodo1(long  i)
	{
		System.out.println("Integer");
	}
}
