package ocjp.primitivos;

public class Ejercicio4 {

	public static void main(String[] args) 
	{
		Ejercicio4 o = new Ejercicio4();
		int s1=10;
		o.metodo1(s1);

	}
	
	void metodo1 (short l)
	{
		System.out.println("Short Prmitivo");	
	} 
	void metodo1(Long i)
	{
		System.out.println("Long");
	}
}
