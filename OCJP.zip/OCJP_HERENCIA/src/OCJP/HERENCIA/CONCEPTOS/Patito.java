package OCJP.HERENCIA.CONCEPTOS;

public class Patito extends Pato 
{

	@Override
	public void dormir() {
		// TODO Auto-generated method stub
		
	}

}
