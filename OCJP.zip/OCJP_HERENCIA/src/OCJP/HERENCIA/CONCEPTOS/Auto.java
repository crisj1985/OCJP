package OCJP.HERENCIA.CONCEPTOS;

public class Auto implements Lavable,Convertible
{

	public void convertir() {
		// TODO Auto-generated method stub
		
	}

	public void lavar() {
		// TODO Auto-generated method stub
		
	}

	public void secar() {
		// TODO Auto-generated method stub
		
	}

}
