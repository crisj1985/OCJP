package OCJP.HERENCIA.CONCEPTOS;

public abstract class  Animal 
{
	public abstract void dormir(); //un metodo abstracto no tiene implementacion y si un metodo abstracto de estar una e}una clase abstracta
   //las clases abstractas no se instancian(ERROR DE COMPILACION) 
    
    public void comer()  
    {  
        System.out.println("animal comiendo");
    }

}
