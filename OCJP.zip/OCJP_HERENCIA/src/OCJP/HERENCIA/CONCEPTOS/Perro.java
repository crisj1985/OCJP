package OCJP.HERENCIA.CONCEPTOS;

public class Perro extends Animal
{
	public void ladrar()  
    {  
        System.out.println("perro ladrando");
    }
    @Override
    public void dormir()  
    {  
        System.out.println("perro durmiendo");
    }
       

}
