package OCJP.HERENCIA.CONCEPTOS;

public class Puma extends Animal implements Extraible,Lavable
{

	public void convertir() {
		// TODO Auto-generated method stub
		
	}

	public void lavar() {
		// TODO Auto-generated method stub
		
	}

	public void secar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dormir() {
		// TODO Auto-generated method stub
		
	}

}
