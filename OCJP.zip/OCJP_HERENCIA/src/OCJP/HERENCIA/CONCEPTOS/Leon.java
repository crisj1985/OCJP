package OCJP.HERENCIA.CONCEPTOS;

public class Leon extends Animal
{

	@Override
	public void dormir() 
	{
		// TODO Auto-generated method stub
		
	}
	

}
