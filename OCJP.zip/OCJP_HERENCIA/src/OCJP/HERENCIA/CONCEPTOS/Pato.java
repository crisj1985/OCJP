package OCJP.HERENCIA.CONCEPTOS;

public abstract class Pato extends Animal
{
	
}
