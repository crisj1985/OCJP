package OCJP.HERENCIA.CONCEPTOS;

public class Gato extends Animal 
{
	public void dormir()
	{
		System.out.println("gato durmiendo");
	}

}
