package OCJP.HERENCIA.CONCEPTOS;

public interface Extraible extends Lavable, Convertible
{

}
