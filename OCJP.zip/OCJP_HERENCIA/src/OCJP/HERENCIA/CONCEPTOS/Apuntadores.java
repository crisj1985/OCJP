package OCJP.HERENCIA.CONCEPTOS;

public class Apuntadores {

	public static void main(String[] args) {
		Perro p2=new Perro();
        Animal a2 = new Perro();
        Object o1 = new Perro();
        a2.dormir();
        

	}

}
