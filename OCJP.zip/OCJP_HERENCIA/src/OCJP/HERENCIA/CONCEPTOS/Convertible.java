package OCJP.HERENCIA.CONCEPTOS;

public interface Convertible 
{
	public void convertir();

}
