package OCJP.HERENCIA.CONCEPTOS;

public class Ropa implements Lavable
{

	public void lavar() {
		// TODO Auto-generated method stub
		
	}

	public void secar() {
		// TODO Auto-generated method stub
		
	}
	

}
