package OCJP.HERENCIA.CONCEPTOS;

public class Test_herencia {

	public static void main(String[] args) 
	{
		//Animal a1 = new Animal();
        Perro p1 = new Perro();
        p1.comer();
        p1.dormir();
        p1.ladrar();
        //p1.toString();

	}

}
