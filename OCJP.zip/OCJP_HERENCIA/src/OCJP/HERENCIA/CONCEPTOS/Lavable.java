package OCJP.HERENCIA.CONCEPTOS;

public interface Lavable 
{
	public void lavar();
	public abstract void secar();
	
}
