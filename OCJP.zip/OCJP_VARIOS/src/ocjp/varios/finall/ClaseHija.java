package ocjp.varios.finall;

public class ClaseHija extends ClasePadre 
{
//	void m3()
//	{
//		
//	}
	void m4()
	{
		this.m3();
		Auto a = new Auto();
		a.m6(a);
		
	}
}
