package ocjp.varios.finall;

public final class Final 
{

}
