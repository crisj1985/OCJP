package ocjp.varios.finall;

public abstract class ClaseAbstract {

	public ClaseAbstract() {
		// TODO Auto-generated constructor stub
	}
	
	public abstract void m2();
	

}
