package ocjp.varios.finall;

public class ClasePadre 
{
//	private final String atr1;
	private final String atr2="a";
	private final String atr3;
	private final String atr4;
	{
		atr3="b";
	}
	public ClasePadre() {
		atr4="c";
	}

	final void m3()
	{
		atr2="a";
		atr3="b";
		atr4="c";
	}
}
