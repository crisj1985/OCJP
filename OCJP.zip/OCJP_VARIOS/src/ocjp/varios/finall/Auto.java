package ocjp.varios.finall;

public class Auto 
{
	String marca;
	
	void m6 (final Auto a)
	{
		
	}
}
