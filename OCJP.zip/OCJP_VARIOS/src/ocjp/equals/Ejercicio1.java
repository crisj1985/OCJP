package ocjp.equals;

public class Ejercicio1 {

	public static void main(String[] args) 
	{
		Integer a =300;
		Integer b =a;
		int x=300;
		int y=300;
		float c=127;
		float d=127;
		Double e=127.0;
		Double d=127.0;
		
		if(c==d)//.equals(b))
			System.out.println("iguales");
		else 
			System.out.println("diferentes");
			
		

	}

}
