package ocjp.equals;

public class Ejercicio2 {

}
