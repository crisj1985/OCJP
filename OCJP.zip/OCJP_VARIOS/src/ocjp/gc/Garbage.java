package ocjp.gc;

public class Garbage {

	
	public void finalize()
	{
		System.out.println("Antes de morir");
	}
}
