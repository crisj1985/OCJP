package ocjp.modificadores.paquete1;

public class ClaseA 
{
	public void metodoPublic()
	{
		
	}
	private void metodoPrivate()
	{
		
	}
	void metodoDefalut()
	{
		
	}
	protected void metodoProtected()
	{
		
	}

}
