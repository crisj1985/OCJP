package ocjp.modifcadores.paq;

import ocjp.modificadores.paquete1.ClaseA;

public class ClaseB 
{
	public void metodo1()
		{
			ClaseA ca1 = new ClaseA();
			ca1.metodoDefalut();
			ca1.metodoProtected();
			ca1.metodoPublic();
		}
}
