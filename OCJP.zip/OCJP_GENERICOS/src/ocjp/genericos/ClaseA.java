package ocjp.genericos;

public class ClaseA <T>
{
	T atributo1;
	public void metodo1(T p1,T T2)
	{
		
	}
	public void metodo2(T p1)
	{
		atributo1=p1;
	}
	public T metodo3()
	{
		return null;
	}
	{

	}
	public <A> void m1 (A a)
	{

	}
}
