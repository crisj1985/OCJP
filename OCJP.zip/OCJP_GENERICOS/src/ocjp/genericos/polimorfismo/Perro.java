package ocjp.genericos.polimorfismo;

public class Perro extends Animal {

}
