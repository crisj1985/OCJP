package ocjp.genericos.polimorfismo;

public class Animal 
{

}
