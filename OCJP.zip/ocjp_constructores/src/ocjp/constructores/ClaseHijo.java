package ocjp.constructores;

public class ClaseHijo extends ClasePadre
{
	/*public ClaseHijo()
	{
		this("");
        System.out.println("C");
        
    }
    public ClaseHijo (String nombre)
    {
       	  System.out.println("D"); 
    }*/
	 	{
	        System.out.println("BI-Hijo");
	    }
	    public ClaseHijo(){
	        
	        System.out.println("C");
	        
	    }
	    
	    public ClaseHijo (String nombre){
	        
	        System.out.println("D");       
	    }
}
