package ocjp.constructores;

public class ClasePadre 
{
	/*public ClasePadre ()
	{
		this("");
        System.out.println("A");
    }
    public ClasePadre (String nombre)
    {
    	
        System.out.println("B");
    }*/
	 	{
	        System.out.println("BI-PADRE I");
	    }
	    public ClasePadre (){
	        System.out.println("A");
	    }
	    public ClasePadre (String nombre){
	        System.out.println("B");
	    }
	    {
	        System.out.println("BI-PADRE II");
	    }

}
