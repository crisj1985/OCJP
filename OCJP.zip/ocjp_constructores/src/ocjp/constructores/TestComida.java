package ocjp.constructores;

public class TestComida {

	public static void main(String[] args) 
	{
		Pizza pz = new Pizza();
	}

}
