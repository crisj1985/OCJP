package ocjp.constructores;

public class Pizza extends Comida
{
	public Pizza ()
	{
		super();
		System.out.println("huele a pizza");
		
	}

	{
		System.out.println("Bloque de inicializacion hija 1");
	}
	
}
