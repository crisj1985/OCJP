package ocjp.constructores;

public class TestConstructores {

	public static void main(String[] args) 
	{
		ClaseHijo ch= new ClaseHijo("a");
		

	}

}
