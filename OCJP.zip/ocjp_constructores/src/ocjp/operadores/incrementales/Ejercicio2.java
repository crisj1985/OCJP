package ocjp.operadores.incrementales;

public class Ejercicio2 {

	public static void main(String[] args) 
	{
		int a=1;
		int x = a++;
		System.out.println("a vale: "+a);
		System.out.println("x vale: "+x);
				

	}

}
