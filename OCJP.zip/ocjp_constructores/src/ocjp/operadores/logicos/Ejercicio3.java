package ocjp.operadores.logicos;

public class Ejercicio3 {

	public static void main(String[] args) 
	{
		String a="";
		int x=10;
		a=(x>10)?"hola":"chao";
		System.out.println(a);

	}

}
