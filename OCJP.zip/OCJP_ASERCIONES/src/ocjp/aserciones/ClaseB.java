package ocjp.aserciones;

public class ClaseB {

	public static void main(String[] args) {
		int a=10;
		assert(a<2):"Invalido";
		System.out.println("Prueba3");

	}

}
